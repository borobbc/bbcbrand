#!/usr/bin/env python3
"""
BBC BRAND — бот-пульт для сайта на Cloudflare.
Без сторонних библиотек: только стандартный Python 3.8+.

Сайт, наличие и заказы живут на Cloudflare. Этот бот:
  • админ-панель: наличие по цветам, таймер дропа, цена, реквизиты, заказы;
  • кнопки заказов (оплачен / отправлен + ТТН / отменить);
  • сообщает, когда стартует дроп.
Новые заказы присылает сам сайт (Cloudflare) — сразу админам в этот бот.

Настройки — в config.json рядом с этим файлом.
"""
import json, os, sys, time, threading, re, urllib.request, urllib.error, traceback
from datetime import datetime, timedelta, timezone

BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE, 'config.json')
LOCAL_FILE = os.path.join(BASE, 'bot_data.json')

with open(CONFIG_FILE, encoding='utf-8') as f:
    CFG = json.load(f)
CFG['bot_token'] = os.environ.get('BOT_TOKEN') or CFG.get('bot_token', '')
CFG['admin_ids'] = [int(x) for x in CFG.get('admin_ids', [])]
CFG['site_url'] = (CFG.get('site_url') or '').strip().rstrip('/')
CFG['admin_secret'] = CFG.get('admin_secret', '')
CFG.setdefault('currency', '₴')
CFG.setdefault('contact', '@bbcbrand')

if not CFG['bot_token'] or 'ВСТАВЬ' in CFG['bot_token']:
    print('!! Укажи bot_token в config.json'); sys.exit(1)
if not CFG['site_url'].startswith('https://'):
    print('!! Укажи site_url — адрес сайта на Cloudflare, например https://bbcbrand.pages.dev'); sys.exit(1)
if not CFG['admin_secret'] or 'ВСТАВЬ' in CFG['admin_secret']:
    print('!! Укажи admin_secret (тот же, что ADMIN_SECRET на Cloudflare)'); sys.exit(1)

TG = f"https://api.telegram.org/bot{CFG['bot_token']}/"
COLORS = {'black': ('Чёрный', '⚫'), 'red': ('Бордовый', '🔴'), 'white': ('Белый', '⚪')}
ORDER = ['black', 'red', 'white']
try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo('Europe/Kyiv')
except Exception:
    TZ = timezone(timedelta(hours=2))

# ---------------------------------------------------------------- local cache
LOCAL = {'photo_ids': {}, 'drop_notified': {}}
if os.path.exists(LOCAL_FILE):
    try:
        LOCAL.update(json.load(open(LOCAL_FILE, encoding='utf-8')))
    except Exception:
        pass

def save_local():
    tmp = LOCAL_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(LOCAL, f, ensure_ascii=False)
    os.replace(tmp, LOCAL_FILE)

# ---------------------------------------------------------------- site api
class SiteError(Exception):
    pass

def site(action='get', **kw):
    return site_raw(action, **kw)['state']

def site_raw(action='get', **kw):
    body = json.dumps({'action': action, **kw}, ensure_ascii=False).encode()
    req = urllib.request.Request(CFG['site_url'] + '/api/admin', data=body, headers={
        'Content-Type': 'application/json', 'X-Admin-Secret': CFG['admin_secret'], 'User-Agent': 'bbc-bot'})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            res = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get('error')
        except Exception:
            msg = str(e)
        raise SiteError(f'сайт ответил {e.code}: {msg}')
    except Exception as e:
        raise SiteError(f'нет связи с сайтом: {e}')
    return res

def now_ms():
    return int(time.time() * 1000)

def eff(p):
    if p.get('drop_at') and now_ms() < p['drop_at']:
        return 'drop'
    if p.get('drop_at') and now_ms() >= p['drop_at']:
        return 'in_stock'
    return 'in_stock' if p.get('status') == 'in_stock' else 'out'

def fmt_left(ms):
    s = max(0, ms // 1000)
    d, s = divmod(s, 86400); h_, s = divmod(s, 3600); m, s = divmod(s, 60)
    return (f'{d}д ' if d else '') + f'{h_:02}:{m:02}:{s:02}'

def fmt_dt(ms):
    return datetime.fromtimestamp(ms / 1000, TZ).strftime('%d.%m %H:%M')

def price_txt(p):
    return f"{p['price']:,} {CFG['currency']}".replace(',', ' ') if p.get('price') else 'не задана'

def h(s):
    return str(s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

# ---------------------------------------------------------------- telegram
def tg(method, params=None, timeout=35):
    req = urllib.request.Request(TG + method, data=json.dumps(params or {}, ensure_ascii=False).encode(),
                                 headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            res = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            res = json.loads(e.read().decode())
        except Exception:
            res = {'ok': False, 'description': str(e)}
    except Exception as e:
        res = {'ok': False, 'description': str(e)}
    if not res.get('ok') and 'message is not modified' not in str(res.get('description', '')):
        print('TG', method, res.get('description'))
    return res

def kb(rows):
    return {'inline_keyboard': [[{'text': t, 'url': d} if d.startswith('http') else {'text': t, 'callback_data': d} for t, d in row] for row in rows]}

def send(chat, text, rows=None):
    p = {'chat_id': chat, 'text': text, 'parse_mode': 'HTML', 'disable_web_page_preview': True}
    if rows is not None:
        p['reply_markup'] = kb(rows)
    return tg('sendMessage', p)

def edit(chat, mid, text, rows=None, is_photo=False):
    p = {'chat_id': chat, 'message_id': mid, 'parse_mode': 'HTML'}
    if rows is not None:
        p['reply_markup'] = kb(rows)
    if is_photo:
        p['caption'] = text
        return tg('editMessageCaption', p)
    p['text'] = text; p['disable_web_page_preview'] = True
    return tg('editMessageText', p)

# ---------------------------------------------------------------- admin ui
PENDING = {}

def is_admin(uid):
    return uid in CFG['admin_ids']

def main_menu_rows():
    return [[('📦 Товар', 'menu:goods'), ('🧾 Заказы', 'menu:orders')], [('💳 Реквизиты', 'menu:pay'), ('🏷 NFC-метки', 'menu:tags')],
            [('🌐 Открыть сайт', CFG['site_url'])]]

def main_menu_text(st):
    lines = ['<b>Админ-панель BBC BRAND</b>', '']
    for k in ORDER:
        p = st['products'][k]; e = eff(p)
        s = '✅ в наличии' if e == 'in_stock' else (f'⏳ дроп через {fmt_left(p["drop_at"] - now_ms())}' if e == 'drop' else '❌ нет в наличии')
        lines.append(f'{COLORS[k][1]} {COLORS[k][0]} — {s} · {price_txt(p)}')
    new = sum(1 for o in st.get('orders', []) if o['status'] == 'new')
    lines += ['', f'Новых заказов: <b>{new}</b>', f'🌐 {CFG["site_url"]}']
    return '\n'.join(lines)

def goods_rows():
    return [[(f'{COLORS[k][1]} {COLORS[k][0]}', f'p:{k}')] for k in ORDER] + [[('⬅️ Назад', 'menu:main')]]

def product_caption(k, st):
    p = st['products'][k]; e = eff(p)
    if e == 'in_stock':
        s = '✅ <b>В наличии</b> — на сайте можно заказать'
    elif e == 'drop':
        s = f'⏳ <b>Дроп</b> через {fmt_left(p["drop_at"] - now_ms())}\n🕒 Старт: {fmt_dt(p["drop_at"])} (Киев)'
    else:
        s = '❌ <b>Нет в наличии</b>'
    return f'{COLORS[k][1]} <b>Картхолдер BBC BRAND — {COLORS[k][0]}</b>\n\n{s}\n💰 Цена: {price_txt(p)}'

def product_rows(k):
    return [[('✅ В наличии', f'st:{k}:in'), ('❌ Нет в наличии', f'st:{k}:out')],
            [('⏳ Таймер дропа', f'tm:{k}')],
            [('💰 Цена', f'pr:{k}'), ('🔄 Обновить', f'p:{k}')],
            [('⬅️ К товарам', 'back:goods')]]

def timer_rows(k):
    rows, row = [], []
    for x in [1, 3, 6, 12, 24, 48, 72]:
        row.append((f'{x} ч', f'ts:{k}:{x}'))
        if len(row) == 4:
            rows.append(row); row = []
    if row: rows.append(row)
    rows.append([('✏️ Своё время', f'tc:{k}'), ('🗑 Убрать таймер', f'tx:{k}')])
    rows.append([('⬅️ Назад', f'p:{k}')])
    return rows

IMG_VER = '2'  # новые холдеры BIG BUCKS CLUB

def send_product(chat, k, st):
    pk = f'{k}:{IMG_VER}'
    url = f"{CFG['site_url']}/img/{k}.jpg?v={IMG_VER}"
    params = {'chat_id': chat, 'caption': product_caption(k, st), 'parse_mode': 'HTML', 'reply_markup': kb(product_rows(k)),
              'photo': LOCAL['photo_ids'].get(pk) or url}
    r = tg('sendPhoto', params)
    if not r.get('ok') and LOCAL['photo_ids'].get(pk):
        params['photo'] = url; r = tg('sendPhoto', params)
    if r.get('ok'):
        LOCAL['photo_ids'][pk] = r['result']['photo'][-1]['file_id']; save_local()
    else:
        send(chat, product_caption(k, st), product_rows(k))

ORDER_ST = {'new': '🆕 новый', 'paid': '💸 оплачен', 'sent': '📦 отправлен', 'cancel': '❌ отменён'}
PAY_ST = {'review': '🧾 скрин оплаты на проверке', 'ok': '✅ оплата подтверждена', 'bad': '🚫 оплата отклонена'}

def order_text(o):
    t = [f'🧾 <b>Заказ {h(o["id"])}</b> · {ORDER_ST.get(o["status"], o["status"])}',
         f'{COLORS[o["color"]][1]} Картхолдер — {COLORS[o["color"]][0]} · {h(o.get("price_txt"))}', '',
         f'👤 {h(o["last_name"])} {h(o["first_name"])}', f'📞 <code>{h(o["phone"])}</code>']
    if o.get('delivery') == 'eu':
        t += [f'🇪🇺 <b>Европа</b> · предоплата от ₴{o.get("prepay") or 390}',
              f'🌍 {h(o.get("country"))}, {h(o.get("city"))}, {h(o.get("zip"))}', f'🏠 {h(o.get("address"))}']
    else:
        t += [f'🇺🇦 Украина · предоплата ₴{o.get("prepay") or 150}', f'🏙 {h(o.get("city"))}', f'📮 НП: {h(o.get("np"))}']
    if o.get('pay') in PAY_ST: t.append(PAY_ST[o['pay']])
    if o.get('telegram'): t.append(f'✈️ {h(o["telegram"])}')
    if o.get('comment'): t.append(f'💬 {h(o["comment"])}')
    if o.get('ttn'): t.append(f'🚚 ТТН: <code>{h(o["ttn"])}</code>')
    t.append(f'\n🕒 {fmt_dt(o["created"])}')
    return '\n'.join(t)

def order_rows(o):
    rows = []
    if o['status'] == 'new': rows.append([('💸 Оплачен', f'os:{o["id"]}:paid'), ('🚫 Отклонить оплату', f'oj:{o["id"]}')])
    if o['status'] in ('new', 'paid'): rows.append([('📦 Отправлен + ТТН', f'ot:{o["id"]}')])
    if o['status'] != 'cancel': rows.append([('❌ Отменить', f'os:{o["id"]}:cancel')])
    return rows

def find_order(st, rid):
    return next((o for o in st.get('orders', []) if o['id'] == rid), None)

def orders_list_rows(st):
    last = list(reversed(st.get('orders', [])[-12:]))
    rows = [[(f'{"🧾 " if o.get("pay") == "review" else ""}{o["id"]} · {COLORS[o["color"]][1]} · {ORDER_ST[o["status"]]} · {o["last_name"]}', f'oo:{o["id"]}')] for o in last]
    return rows + [[('⬅️ Назад', 'menu:main')]]

def parse_time(text):
    t = text.strip().lower().replace(',', '.')
    m = re.fullmatch(r'(\d+(?:\.\d+)?)\s*(ч|час|часа|часов|h)?', t)
    if m:
        return now_ms() + int(float(m.group(1)) * 3600 * 1000)
    m = re.fullmatch(r'(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?\s+(\d{1,2})[:.](\d{2})', t)
    if m:
        d, mo, y, hh, mm = m.groups()
        y = int(y) if y else datetime.now(TZ).year
        if y < 100: y += 2000
        try:
            return int(datetime(y, int(mo), int(d), int(hh), int(mm), tzinfo=TZ).timestamp() * 1000)
        except ValueError:
            return None
    return None

# ---------------------------------------------------------------- nfc tags
def tag_url(code):
    return f"{CFG['site_url']}/id?c={code}"

def fcode(c):
    return c[:4] + '-' + c[4:] if len(c) == 8 else c

def tnum(t, total):
    return '№' + str(t['n']).zfill(max(3, len(str(total))))

def tags_menu(res):
    T = res['tags']; items = T['items']
    scanned = sum(1 for t in items if t.get('first_scan'))
    lines = ['🏷 <b>NFC-метки</b>', '',
             f'Создано: <b>{T["seq"]}</b> из {T["total"]} · активных {T["count"]}',
             f'Уже проверяли: {scanned}', '',
             'Каждая метка — своя ссылка. Когда её сканируют, сайт показывает «Оригинал», 3D-модель нужного цвета и номер «из тиража».']
    rows = [[('➕ Новая метка', 'tn')], [('📋 Список меток', 'tl:0'), (f'🔢 Тираж: {T["total"]}', 'tt')], [('⬅️ В меню', 'menu:main')]]
    return '\n'.join(lines), rows

def color_rows(prefix, back):
    return [[(f'{COLORS[k][1]} {COLORS[k][0]}', f'{prefix}:{k}') for k in ORDER], [('⬅️ Назад', back)]]

def tag_text(t, total, fresh=False):
    c = COLORS.get(t['color'], ('?', '🏷'))
    lines = [f'{"✅ Метка создана" if fresh else "🏷 Метка"} <b>{tnum(t, total)}</b> из {total} · {c[1]} {c[0]}',
             f'Код: <code>{fcode(t["code"])}</code>', '', 'Ссылка для записи на метку:', f'<code>{tag_url(t["code"])}</code>', '']
    if t.get('first_scan'):
        lines.append(f'👁 Первая проверка: {fmt_dt(t["first_scan"])} · всего проверок: {t.get("scans", 0)}')
    else:
        lines.append('👁 Ещё не сканировали')
    if fresh:
        lines += ['', '<b>Как записать:</b> NFC Tools → Записать → Добавить запись → URL/URI → вставь ссылку → Записать → приложи метку к телефону.']
    return '\n'.join(lines)

def tag_rows(t):
    c = t['code']
    return [[('👀 Открыть страницу', tag_url(c) + '&peek=1')],
            [('➕ Ещё такую же', f'tc2:{t["color"]}'), ('🎨 Цвет', f'tk:{c}')],
            [('♻️ Сбросить проверки', f'tr:{c}'), ('🗑 Удалить', f'td:{c}')],
            [('⬅️ К меткам', 'menu:tags')]]

def tags_list(res, page):
    T = res['tags']; items = T['items']; per = 10
    chunk = items[page * per:(page + 1) * per]
    if not items:
        return '📋 Меток пока нет. Нажми «➕ Новая метка».', [[('➕ Новая метка', 'tn')], [('⬅️ Назад', 'menu:tags')]]
    rows = [[(f'{tnum(t, T["total"])} {COLORS.get(t["color"], ("", "🏷"))[1]} {fcode(t["code"])} {"👁" if t.get("first_scan") else "·"}', f'tg:{t["code"]}')] for t in chunk]
    nav = []
    if page > 0: nav.append(('◀️', f'tl:{page - 1}'))
    if (page + 1) * per < len(items): nav.append(('▶️', f'tl:{page + 1}'))
    if nav: rows.append(nav)
    rows.append([('⬅️ Назад', 'menu:tags')])
    return f'📋 <b>Метки</b> ({len(items)}) · 👁 — уже сканировали', rows

# ---------------------------------------------------------------- handlers
def on_message(m):
    chat = m['chat']['id']; uid = m.get('from', {}).get('id'); text = (m.get('text') or '').strip()
    if text == '/id':
        send(chat, f'Твой Telegram ID: <code>{uid}</code>'); return
    if not is_admin(uid):
        send(chat, f'Привет! Это бот магазина <b>BBC BRAND</b>.\n\nЗаказы оформляются на сайте. Вопросы — {h(CFG["contact"])}.',
             [[('🛍 Открыть магазин', CFG['site_url'])]])
        return
    try:
        if text.startswith('/start') or text in ('/admin', '/menu'):
            PENDING.pop(chat, None); send(chat, main_menu_text(site()), main_menu_rows()); return
        pend = PENDING.get(chat)
        if not pend:
            send(chat, 'Открой меню: /admin'); return
        action, arg = pend
        if text.lower() in ('/cancel', 'отмена'):
            PENDING.pop(chat, None); send(chat, 'Отменено.', main_menu_rows()); return
        if action == 'price':
            digits = re.sub(r'[^\d]', '', text)
            if not digits:
                send(chat, 'Пришли цену числом, например <code>899</code>. Убрать цену — <code>0</code>.'); return
            st = site('product', color=arg, price=int(digits) or None); PENDING.pop(chat, None)
            send(chat, f'💰 Цена обновлена: {price_txt(st["products"][arg])}'); send_product(chat, arg, st); return
        if action == 'timer':
            ts = parse_time(text)
            if not ts:
                send(chat, 'Не понял время. Пришли количество часов (например <code>36</code>) или дату <code>25.11 20:00</code> (по Киеву).'); return
            if ts <= now_ms():
                send(chat, 'Это время уже прошло. Пришли время в будущем.'); return
            st = site('product', color=arg, drop_at=ts); LOCAL['drop_notified'].pop(arg, None); save_local(); PENDING.pop(chat, None)
            send(chat, f'⏳ Таймер поставлен: старт {fmt_dt(ts)} (через {fmt_left(ts - now_ms())})'); send_product(chat, arg, st); return
        if action == 'pay':
            st = site('payment', text=text[:1500]); PENDING.pop(chat, None)
            send(chat, '💳 Реквизиты обновлены. Так их увидит покупатель после заказа:\n\n' + h(st['payment']), [[('⬅️ В меню', 'menu:main')]]); return
        if action == 'total':
            digits = re.sub(r'[^\d]', '', text)
            if not digits or int(digits) < 1:
                send(chat, 'Пришли число, например <code>500</code>.'); return
            res = site_raw('tag_total', total=int(digits)); PENDING.pop(chat, None)
            t, r = tags_menu(res); send(chat, f'🔢 Тираж: {res["tags"]["total"]}\n\n' + t, r); return
        if action == 'ttn':
            st = site('order', id=arg, status='sent', ttn=text[:40]); PENDING.pop(chat, None)
            o = find_order(st, arg)
            if o: send(chat, order_text(o), order_rows(o))
            return
    except SiteError as e:
        send(chat, f'⚠️ Не получилось: {h(e)}')

def on_callback(q):
    cid = q['id']; uid = q['from']['id']; data = q.get('data', '')
    msg = q.get('message') or {}
    chat = msg.get('chat', {}).get('id'); mid = msg.get('message_id'); is_photo = 'photo' in msg or 'document' in msg
    if not is_admin(uid):
        tg('answerCallbackQuery', {'callback_query_id': cid, 'text': 'Нет доступа'}); return
    ans = ''
    def to_text(text, rows):
        if is_photo:
            tg('deleteMessage', {'chat_id': chat, 'message_id': mid}); send(chat, text, rows)
        else:
            edit(chat, mid, text, rows)
    try:
        if data == 'menu:main':
            PENDING.pop(chat, None); to_text(main_menu_text(site()), main_menu_rows())
        elif data in ('menu:goods', 'back:goods'):
            to_text('📦 <b>Товар</b>\nВыбери цвет:', goods_rows())
        elif data == 'menu:orders':
            st = site(); to_text('🧾 <b>Последние заказы</b>' if st.get('orders') else '🧾 Заказов пока нет.', orders_list_rows(st))
        elif data == 'menu:pay':
            st = site(); to_text('💳 <b>Реквизиты</b> — покупатель видит их сразу после заказа на сайте:\n\n' + h(st['payment']),
                                 [[('✏️ Изменить', 'pay:edit')], [('⬅️ Назад', 'menu:main')]])
        elif data == 'pay:edit':
            PENDING[chat] = ('pay', None)
            send(chat, 'Пришли новый текст реквизитов одним сообщением (карта, получатель, сумма и т.д.).\nОтмена — /cancel')
        elif data.startswith('p:'):
            k = data[2:]; st = site()
            if is_photo:
                edit(chat, mid, product_caption(k, st), product_rows(k), True)
            else:
                tg('deleteMessage', {'chat_id': chat, 'message_id': mid}); send_product(chat, k, st)
        elif data.startswith('st:'):
            _, k, v = data.split(':')
            st = site('product', color=k, status=v); ans = 'В наличии ✅' if v == 'in' else 'Нет в наличии ❌'
            edit(chat, mid, product_caption(k, st), product_rows(k), is_photo)
        elif data.startswith('tm:'):
            k = data[3:]; st = site()
            edit(chat, mid, product_caption(k, st) + '\n\n⏳ <b>Через сколько открыть дроп?</b>', timer_rows(k), is_photo)
        elif data.startswith('ts:'):
            _, k, hrs = data.split(':')
            st = site('product', color=k, drop_at=now_ms() + int(hrs) * 3600 * 1000)
            LOCAL['drop_notified'].pop(k, None); save_local(); ans = f'Таймер: {hrs} ч'
            edit(chat, mid, product_caption(k, st), product_rows(k), is_photo)
        elif data.startswith('tc:'):
            k = data[3:]; PENDING[chat] = ('timer', k)
            send(chat, f'{COLORS[k][1]} Пришли время дропа:\n• количество часов — <code>36</code>\n• или дату и время по Киеву — <code>25.11 20:00</code>\nОтмена — /cancel')
        elif data.startswith('tx:'):
            k = data[3:]; st = site('product', color=k, drop_at=None); ans = 'Таймер убран'
            edit(chat, mid, product_caption(k, st), product_rows(k), is_photo)
        elif data.startswith('pr:'):
            k = data[3:]; PENDING[chat] = ('price', k)
            send(chat, f'{COLORS[k][1]} Пришли цену числом в {CFG["currency"]}, например <code>899</code>. Убрать цену — <code>0</code>.\nОтмена — /cancel')
        elif data == 'menu:tags':
            PENDING.pop(chat, None); t, r = tags_menu(site_raw('tags')); to_text(t, r)
        elif data == 'tn':
            to_text('🏷 <b>Новая метка</b>\nВыбери цвет картхолдера:', color_rows('tc2', 'menu:tags'))
        elif data.startswith('tc2:'):
            k = data[4:]; res = site_raw('tag_new', color=k); t = res['tag']; ans = f'Метка {tnum(t, res["tags"]["total"])} создана'
            if res['tags']['seq'] > res['tags']['total']:
                send(chat, f'⚠️ Номер {t["n"]} больше тиража {res["tags"]["total"]}. Увеличь тираж в меню меток.')
            send(chat, tag_text(t, res['tags']['total'], True), tag_rows(t))
        elif data.startswith('tl:'):
            t, r = tags_list(site_raw('tags'), int(data[3:])); to_text(t, r)
        elif data.startswith('tg:'):
            res = site_raw('tag_get', code=data[3:]); to_text(tag_text(res['tag'], res['tags']['total']), tag_rows(res['tag']))
        elif data.startswith('tk:'):
            c = data[3:]; to_text(f'🎨 Новый цвет для метки <code>{fcode(c)}</code>:', color_rows(f'tk2:{c}', f'tg:{c}'))
        elif data.startswith('tk2:'):
            _, c, k = data.split(':'); res = site_raw('tag_color', code=c, color=k); ans = 'Цвет изменён'
            to_text(tag_text(res['tag'], res['tags']['total']), tag_rows(res['tag']))
        elif data.startswith('tr:'):
            res = site_raw('tag_reset', code=data[3:]); ans = 'Проверки сброшены'
            to_text(tag_text(res['tag'], res['tags']['total']), tag_rows(res['tag']))
        elif data.startswith('td:'):
            c = data[3:]; to_text(f'🗑 Удалить метку <code>{fcode(c)}</code>? Её ссылка перестанет работать — сайт покажет «Метка не найдена».',
                                  [[('Да, удалить', f'tdy:{c}')], [('⬅️ Нет', f'tg:{c}')]])
        elif data.startswith('tdy:'):
            res = site_raw('tag_del', code=data[4:]); ans = 'Метка удалена'; t, r = tags_menu(res); to_text(t, r)
        elif data == 'tt':
            PENDING[chat] = ('total', None)
            send(chat, '🔢 Пришли размер тиража числом — сколько картхолдеров всего (будет «№ 001 / <b>500</b>»).\nОтмена — /cancel')
        elif data.startswith('oo:'):
            st = site(); o = find_order(st, data[3:])
            if o: edit(chat, mid, order_text(o), order_rows(o) + [[('⬅️ К заказам', 'menu:orders')]])
        elif data.startswith('os:'):
            _, rid, v = data.split(':')
            st = site('order', id=rid, status=v); o = find_order(st, rid); ans = ORDER_ST.get(v, v)
            if o: edit(chat, mid, order_text(o), order_rows(o), is_photo)
        elif data.startswith('oj:'):
            rid = data[3:]; st = site('order', id=rid, pay='bad'); o = find_order(st, rid); ans = 'Оплата отклонена'
            if o: edit(chat, mid, order_text(o), order_rows(o), is_photo)
        elif data.startswith('ot:'):
            rid = data[3:]; PENDING[chat] = ('ttn', rid)
            send(chat, f'🚚 Пришли номер ТТН для заказа {rid}.\nОтмена — /cancel')
    except SiteError as e:
        ans = 'Ошибка связи с сайтом'
        send(chat, f'⚠️ Не получилось: {h(e)}')
    except Exception:
        traceback.print_exc()
    tg('answerCallbackQuery', {'callback_query_id': cid, 'text': ans})

def watcher():
    while True:
        time.sleep(30)
        try:
            st = site()
            for k in ORDER:
                p = st['products'][k]
                if p.get('drop_at') and now_ms() >= p['drop_at'] and not LOCAL['drop_notified'].get(k):
                    site('product', color=k, status='in')
                    LOCAL['drop_notified'][k] = True; save_local()
                    for a in CFG['admin_ids']:
                        send(a, f'🚀 Дроп стартовал: {COLORS[k][1]} {COLORS[k][0]} — теперь «в наличии» на сайте.')
        except SiteError as e:
            print('watcher:', e)
        except Exception:
            traceback.print_exc()

def poll():
    tg('deleteWebhook', {})
    me = tg('getMe').get('result', {})
    print(f"Бот @{me.get('username')} запущен. Сайт: {CFG['site_url']}. Админы: {CFG['admin_ids']}")
    try:
        site(); print('Связь с сайтом: OK')
    except SiteError as e:
        print('!! Связь с сайтом не работает:', e)
    offset = 0
    while True:
        r = tg('getUpdates', {'offset': offset, 'timeout': 25, 'allowed_updates': ['message', 'callback_query']}, timeout=40)
        if not r.get('ok'):
            time.sleep(3); continue
        for u in r['result']:
            offset = u['update_id'] + 1
            try:
                if 'message' in u: on_message(u['message'])
                elif 'callback_query' in u: on_callback(u['callback_query'])
            except Exception:
                traceback.print_exc()

if __name__ == '__main__':
    threading.Thread(target=watcher, daemon=True).start()
    poll()
